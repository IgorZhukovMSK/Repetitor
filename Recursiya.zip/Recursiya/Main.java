package Recursiya;

public class Main {

    public static void main(String[] args) {

        Recursiya num = new Recursiya(new int[]{891, 5897, 18, 5489});
    }
}
