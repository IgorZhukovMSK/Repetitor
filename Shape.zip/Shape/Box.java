package Shape;

// реализовать метод подсчета объема

public class Box {

    private double length, width, height;


    public Box(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;

        double volume = length * width * height;

        if (length <= 0 || width <= 0 || height <= 0) {
            System.out.println("Вы ввели не правильные данные!!! Проверьте ввод!!!");
        } else {

            System.out.println("Объем коробки равен: " + volume + " куб. м.");

        }
    }
}
