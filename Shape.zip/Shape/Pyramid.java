package Shape;

public class Pyramid {

    private double height, area;

    public Pyramid(double area, double height) {

        this.height = height;
        this.area = area;

        if (height <= 0 || area <= 0) {
            System.out.println("Вы ввели не правильные данные!!! Проверьте ввод!!!");
        } else {

            double volume = (((double) 1 / 3) * area * height);

            System.out.println("Объем пирамиды равен: " + volume + " кв. м.");
        }
    }
}
