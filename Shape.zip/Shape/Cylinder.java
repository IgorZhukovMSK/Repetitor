package Shape;

public class Cylinder {

    private double radius, height;

    public Cylinder(double radius, double height) {

        this.radius = radius;
        this.height = height;

        if (radius <= 0 || height <= 0) {
            System.out.println("Вы ввели не правильные данные!!! Проверьте ввод!!!");
        } else {

            double volume = 3.14 * (Math.pow(radius, 2) * height);

            System.out.println("Объем цилиндра равен " + volume + " куб. м.");
        }
    }
}
