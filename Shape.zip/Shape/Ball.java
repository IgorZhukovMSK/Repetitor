package Shape;

public class Ball {

    private double radius;

    public Ball(double radius) {
        this.radius = radius;

        if (radius <= 0) {
            System.out.println("Ошибка!!!!! Введите радиус больше 0");
        } else {

            double valume = (((double) 4 / 3) * 3.14 * Math.pow(radius, 3));

            System.out.println("Объем шара равен: " + valume + " кв. м.");

        }
    }
}
