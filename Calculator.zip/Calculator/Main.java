package Calculator;

public class Main {

    public static void main(String[] args) {

        RootCalculator calc = new RootCalculator(1, 1);

        System.out.println(calc.getRoot());
    }
}
